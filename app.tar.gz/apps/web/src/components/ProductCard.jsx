
import React, { useState } from 'react';
import { useCart } from '@/contexts/CartContext.jsx';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { ShoppingCart, Check, Music } from 'lucide-react';
import { toast } from 'sonner';
import pb from '@/lib/pocketbaseClient';

const ProductCard = ({ product }) => {
  const { addToCart } = useCart();
  const [added, setAdded] = useState(false);

  const handleAddToCart = () => {
    addToCart(product);
    setAdded(true);
    toast.success('Added to cart');
    setTimeout(() => setAdded(false), 2000);
  };

  const imageUrl = product.productImage 
    ? pb.files.getUrl(product, product.productImage)
    : null;

  return (
    <Card className="group flex flex-col h-full bg-card border border-border hover:border-primary/50 rounded-2xl overflow-hidden transition-all duration-500 hover:shadow-[0_0_30px_-5px_hsl(var(--primary)/0.3)] hover:-translate-y-1">
      <div className="relative w-full aspect-[4/3] overflow-hidden bg-muted border-b border-border/50">
        {imageUrl ? (
          <img 
            src={imageUrl} 
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center bg-card text-muted-foreground transition-transform duration-500 group-hover:scale-105">
            <Music className="w-12 h-12 mb-2 opacity-30 text-primary" />
            <span className="text-xs uppercase tracking-widest opacity-50">No Cover</span>
          </div>
        )}
        
        {/* Glow overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"></div>
      </div>
      
      <CardContent className="p-6 flex-1 flex flex-col relative z-10 bg-card">
        {product.category && (
          <span className="self-start px-3 py-1 text-[10px] font-bold uppercase tracking-wider bg-primary/10 text-primary border border-primary/30 rounded-full mb-4 shadow-[0_0_10px_hsl(var(--primary)/0.2)]">
            {product.category}
          </span>
        )}
        
        <h3 className="text-xl font-bold text-foreground mb-2 group-hover:text-primary transition-colors duration-300">
          {product.name}
        </h3>
        
        {product.description && (
          <p className="text-sm text-muted-foreground mb-4 line-clamp-2 flex-1">
            {product.description}
          </p>
        )}
        
        <div className="flex items-end justify-between mt-auto pt-4 border-t border-border/50">
          <div>
            {product.fileFormat && (
              <p className="text-xs text-muted-foreground mb-1 uppercase tracking-wider font-semibold">
                {product.fileFormat}
              </p>
            )}
            <p className="text-2xl font-black text-foreground drop-shadow-[0_0_8px_hsl(var(--foreground)/0.2)] group-hover:text-primary transition-colors">
              ${product.price.toFixed(2)}
            </p>
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="p-6 pt-0 bg-card">
        <Button 
          onClick={handleAddToCart}
          className="w-full transition-all duration-300 shadow-[0_0_15px_hsl(var(--primary)/0.2)] hover:shadow-[0_0_25px_hsl(var(--primary)/0.6)] group-hover:bg-primary group-hover:text-primary-foreground font-bold hover:scale-[1.02] active:scale-[0.98]"
          disabled={added}
          variant={added ? "secondary" : "default"}
        >
          {added ? (
            <>
              <Check className="w-5 h-5 mr-2" />
              Added
            </>
          ) : (
            <>
              <ShoppingCart className="w-5 h-5 mr-2" />
              Add to Cart
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ProductCard;
