
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { RefreshCw, Music } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import AudioPlayerCard from '@/components/AudioPlayerCard.jsx';
import { Button } from '@/components/ui/button';

const SoundPreviewPage = () => {
  const [sounds, setSounds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchSounds = async () => {
    setLoading(true);
    setError(null);
    try {
      const records = await pb.collection('sounds').getList(1, 50, {
        sort: '-created',
        $autoCancel: false
      });
      setSounds(records.items);
    } catch (err) {
      console.error('Failed to fetch sounds:', err);
      setError('Failed to load sound library. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSounds();
  }, []);

  return (
    <>
      <Helmet>
        <title>Sound Library - EDM Store</title>
        <meta name="description" content="Preview our premium collection of EDM sounds, loops, and presets." />
      </Helmet>

      <div className="min-h-screen flex flex-col bg-background">
        <Header />

        <main className="flex-1 py-16 relative">
          {/* Background ambient glow */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-primary/5 rounded-full blur-[120px] pointer-events-none"></div>

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="mb-12 text-center md:text-left"
            >
              <h1 className="text-4xl md:text-6xl font-extrabold mb-4" style={{ letterSpacing: '-0.02em' }}>
                Sound Library
              </h1>
              <p className="text-lg text-muted-foreground max-w-2xl">
                Audition our latest premium samples, loops, and one-shots before you buy.
              </p>
            </motion.div>

            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="bg-card border border-border/50 rounded-2xl p-6 animate-pulse">
                    <div className="flex justify-between mb-4">
                      <div className="w-1/3 h-6 bg-muted rounded"></div>
                      <div className="w-16 h-4 bg-muted rounded-full"></div>
                    </div>
                    <div className="w-full h-16 bg-muted/50 rounded mb-4"></div>
                    <div className="flex justify-between items-center pt-4 border-t border-border/50">
                      <div className="w-10 h-10 bg-muted rounded-full"></div>
                      <div className="w-32 h-4 bg-muted rounded"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : error ? (
              <div className="text-center py-24 bg-card rounded-2xl border border-border">
                <p className="text-destructive mb-4">{error}</p>
                <Button onClick={fetchSounds} variant="outline" className="border-border hover:bg-muted">
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Retry
                </Button>
              </div>
            ) : sounds.length > 0 ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.4 }}
                className="grid grid-cols-1 md:grid-cols-2 gap-6"
              >
                {sounds.map((sound, index) => (
                  <motion.div
                    key={sound.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                  >
                    <AudioPlayerCard sound={sound} />
                  </motion.div>
                ))}
              </motion.div>
            ) : (
              <div className="text-center py-32 bg-card rounded-2xl border border-border">
                <div className="w-16 h-16 bg-muted/50 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Music className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="text-xl font-bold mb-2">No sounds available</h3>
                <p className="text-muted-foreground">Check back later for new additions to our library.</p>
              </div>
            )}
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default SoundPreviewPage;
