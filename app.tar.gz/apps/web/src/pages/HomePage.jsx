
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, Zap, Download, Shield } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ThreeDVisualization from '@/components/ThreeDVisualization.jsx';

const HomePage = () => {
  const features = [
    {
      icon: Zap,
      title: 'Premium quality',
      description: 'Professional-grade samples and presets crafted by industry experts'
    },
    {
      icon: Download,
      title: 'Instant access',
      description: 'Download your purchases immediately after checkout'
    },
    {
      icon: Shield,
      title: 'Secure payments',
      description: 'Safe and encrypted transactions powered by Stripe'
    }
  ];

  return (
    <>
      <Helmet>
        <title>EDM Store - Premium music production tools</title>
        <meta name="description" content="Discover premium EDM sample packs, Serum presets, and Phase Plant presets for professional music production" />
      </Helmet>

      <div className="min-h-screen flex flex-col bg-background text-foreground">
        <Header />

        <main className="flex-1">
          <section className="relative min-h-[100dvh] flex items-center justify-center overflow-hidden">
            <div 
              className="absolute inset-0 z-0"
              style={{
                backgroundImage: 'url(https://images.unsplash.com/photo-1627975399961-e88bde8a7648)',
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                filter: 'grayscale(50%) brightness(0.4)'
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-b from-background/95 via-background/80 to-background"></div>
              {/* Neon accent glow */}
              <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-primary/10 rounded-full blur-[120px] pointer-events-none mix-blend-screen"></div>
              <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-accent/10 rounded-full blur-[100px] pointer-events-none mix-blend-screen"></div>
            </div>

            <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-20">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <motion.div
                  initial={{ opacity: 0, x: -30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.8, ease: "easeOut" }}
                  className="text-center lg:text-left"
                >
                  <div className="inline-block mb-6 px-4 py-1.5 rounded-full border border-primary/30 bg-primary/5 backdrop-blur-sm">
                    <span className="text-primary text-sm font-bold tracking-wider uppercase">New Sample Packs Available</span>
                  </div>
                  
                  <h1 className="text-5xl md:text-6xl lg:text-7xl font-extrabold mb-6 leading-tight" style={{ letterSpacing: '-0.03em' }}>
                    Elevate your sound with<br />
                    <span className="bg-gradient-to-r from-primary via-accent to-white bg-clip-text text-transparent drop-shadow-[0_0_20px_hsl(var(--primary)/0.3)] bg-[length:200%_auto] animate-gradient">
                      premium EDM tools
                    </span>
                  </h1>
                  
                  <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-xl mx-auto lg:mx-0 leading-relaxed">
                    Professional sample packs, Serum presets, and Phase Plant presets designed to inject pure energy into your productions.
                  </p>

                  <div className="flex flex-col sm:flex-row gap-5 justify-center lg:justify-start items-center">
                    <Link to="/products">
                      <Button size="lg" className="h-14 px-8 text-base shadow-[0_0_20px_hsl(var(--primary)/0.4)] hover:shadow-[0_0_30px_hsl(var(--primary)/0.6)] hover:bg-primary/90 transition-all duration-300 hover:scale-105 active:scale-95">
                        Browse Products
                        <ArrowRight className="w-5 h-5 ml-2" />
                      </Button>
                    </Link>
                    <Link to="/signup">
                      <Button size="lg" variant="outline" className="h-14 px-8 text-base border-border hover:border-primary hover:text-primary transition-all duration-300 hover:bg-primary/5">
                        Create Account
                      </Button>
                    </Link>
                  </div>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 1, delay: 0.2 }}
                  className="hidden lg:block h-[500px] w-full relative"
                >
                  <ThreeDVisualization />
                </motion.div>
              </div>
            </div>
          </section>

          <section className="py-24 bg-background relative border-t border-border/50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                viewport={{ once: true, margin: "-100px" }}
                className="text-center mb-16"
              >
                <h2 className="text-3xl md:text-4xl font-bold mb-4">
                  Industry-standard Arsenal
                </h2>
                <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
                  Access top-tier production tools trusted by professional artists
                </p>
              </motion.div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {features.map((feature, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    viewport={{ once: true, margin: "-100px" }}
                    className="bg-card rounded-2xl p-8 border border-border hover:border-primary/40 transition-colors duration-300 group"
                  >
                    <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-6 border border-primary/20 group-hover:bg-primary/20 group-hover:scale-110 transition-all duration-300">
                      <feature.icon className="w-7 h-7 text-primary drop-shadow-[0_0_8px_hsl(var(--primary)/0.5)]" />
                    </div>
                    <h3 className="text-xl font-bold mb-3 text-foreground">{feature.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>

          <section className="py-32 relative overflow-hidden">
            <div className="absolute inset-0 bg-card border-t border-b border-border/50"></div>
            {/* Background accent line */}
            <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-accent to-transparent opacity-50"></div>
            
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                viewport={{ once: true }}
              >
                <h2 className="text-3xl md:text-5xl font-bold mb-6">
                  Ready to start creating?
                </h2>
                <p className="text-muted-foreground mb-10 max-w-2xl mx-auto text-lg">
                  Join thousands of producers pushing the boundaries of electronic music.
                </p>
                <Link to="/products">
                  <Button size="lg" className="h-14 px-10 text-lg shadow-[0_0_20px_hsl(var(--primary)/0.4)] hover:shadow-[0_0_30px_hsl(var(--primary)/0.6)] hover:bg-primary/90 transition-all duration-300 hover:scale-105">
                    Explore the Catalog
                    <Zap className="w-5 h-5 ml-2 fill-current" />
                  </Button>
                </Link>
              </motion.div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default HomePage;
