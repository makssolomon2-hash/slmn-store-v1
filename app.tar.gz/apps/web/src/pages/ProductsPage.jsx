
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import pb from '@/lib/pocketbaseClient';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ProductCard from '@/components/ProductCard.jsx';

const ProductsPage = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('all');

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const records = await pb.collection('products').getFullList({
          sort: '-created',
          $autoCancel: false
        });
        setProducts(records);
      } catch (error) {
        console.error('Failed to fetch products:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  const categories = ['all', 'Sample Packs', 'Serum Presets', 'Phase Plant Presets'];
  
  const filteredProducts = selectedCategory === 'all' 
    ? products 
    : products.filter(p => p.category === selectedCategory);

  return (
    <>
      <Helmet>
        <title>Products - EDM Store</title>
        <meta name="description" content="Browse our collection of premium EDM sample packs, Serum presets, and Phase Plant presets" />
      </Helmet>

      <div className="min-h-screen flex flex-col bg-background">
        <Header />

        <main className="flex-1 py-16 relative">
          <div className="absolute top-0 left-0 w-full h-[500px] bg-gradient-to-b from-primary/5 to-transparent pointer-events-none"></div>
          
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="mb-12 text-center md:text-left"
            >
              <h1 className="text-4xl md:text-6xl font-extrabold mb-4" style={{ letterSpacing: '-0.02em' }}>
                Catalog
              </h1>
              <p className="text-lg text-muted-foreground max-w-2xl">
                Discover premium tools engineered for modern electronic music production.
              </p>
            </motion.div>

            <div className="flex flex-wrap justify-center md:justify-start gap-3 mb-12">
              {categories.map(category => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-5 py-2.5 rounded-full text-sm font-bold tracking-wide transition-all duration-300 uppercase ${
                    selectedCategory === category
                      ? 'bg-primary text-primary-foreground shadow-[0_0_15px_hsl(var(--primary)/0.5)] border border-primary'
                      : 'bg-card text-muted-foreground border border-border hover:border-primary/50 hover:text-foreground'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>

            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {[1, 2, 3, 4, 5, 6].map(i => (
                  <div key={i} className="h-[450px] bg-card border border-border/50 rounded-2xl animate-pulse overflow-hidden flex flex-col">
                    <div className="w-full aspect-[4/3] bg-muted/50"></div>
                    <div className="p-6 flex-1 flex flex-col gap-4">
                      <div className="w-20 h-6 bg-muted rounded-full"></div>
                      <div className="w-3/4 h-8 bg-muted rounded"></div>
                      <div className="w-full h-4 bg-muted rounded"></div>
                      <div className="w-1/3 h-8 bg-muted rounded mt-auto"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : filteredProducts.length > 0 ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3 }}
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
              >
                {filteredProducts.map((product, index) => (
                  <motion.div
                    key={product.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <ProductCard product={product} />
                  </motion.div>
                ))}
              </motion.div>
            ) : (
              <div className="text-center py-32 bg-card rounded-2xl border border-border">
                <p className="text-muted-foreground text-lg font-medium">No products found in this category.</p>
                <button 
                  onClick={() => setSelectedCategory('all')}
                  className="mt-4 text-primary hover:underline font-semibold"
                >
                  Clear filters
                </button>
              </div>
            )}
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default ProductsPage;
